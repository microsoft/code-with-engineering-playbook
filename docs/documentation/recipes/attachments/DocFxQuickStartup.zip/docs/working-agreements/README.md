# Working Agreements

You can include working agreements in this folder. Use template documents like working agreements and such from the [Agile Development section in the CSE Playbook](https://github.com/microsoft/code-with-engineering-playbook/tree/main/docs/agile-development).
