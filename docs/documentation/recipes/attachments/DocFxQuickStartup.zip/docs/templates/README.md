# Templates

You can include templates for various standard documents in your project here. Use template documents like working agreements and such from the [Agile Development section in the CSE Playbook](https://github.com/microsoft/code-with-engineering-playbook/tree/main/docs/agile-development), [Design Reviews recipe's section in the CSE Playbook](https://github.com/microsoft/code-with-engineering-playbook/tree/main/docs/design/design-reviews/recipes) and more.
