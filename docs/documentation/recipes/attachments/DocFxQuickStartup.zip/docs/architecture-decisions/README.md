# Architecture Decisions

You can include ADR's in this folder. Use template documents like the high level design recipe and such from the [Design Reviews recipe's section in the CSE Playbook](https://github.com/microsoft/code-with-engineering-playbook/tree/main/docs/design/design-reviews/recipes).
