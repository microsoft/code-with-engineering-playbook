# Cross reference

This folder just contains this readme (obviously) and a `toc.yml` to link various hives from the trees (documentation and reference) together. The result of including this file in the `docfx.json` is that the trees are combined into one.

If you don't want to combine it, remove the reference to this file from `docfx.json`.
